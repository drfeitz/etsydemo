require 'test_helper'

class ListingsHelperTest < ActionView::TestCase
end
