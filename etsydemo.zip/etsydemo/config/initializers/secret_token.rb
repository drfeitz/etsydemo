# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Etsydemo::Application.config.secret_key_base = '23731068ee34351e6ad61233630a5c75d752c42e1f677ef59c4c63a622997421392bb4b960c6598038e04014ef8a99b71ac04edd27d49680c8b7aaea099c49d3'
